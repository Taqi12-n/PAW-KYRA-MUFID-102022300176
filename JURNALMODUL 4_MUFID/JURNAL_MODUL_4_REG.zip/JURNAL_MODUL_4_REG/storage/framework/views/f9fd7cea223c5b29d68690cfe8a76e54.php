

<?php $__env->startSection('content'); ?>
<div class="container mx-auto p-6">
    <?php if(session('error') || session('success')): ?>
        <?php
            $type = session('error') ? 'error' : 'success';
            $message = session($type);
            $bgColor = $type === 'error' ? 'bg-red-500' : 'bg-green-500';
            $id = $type . 'Message';
            $closeFunction = 'close' . ucfirst($type) . 'Message';
        ?>

        <div id="<?php echo e($id); ?>" class="<?php echo e($bgColor); ?> text-white p-4 rounded-lg mb-6 relative">
            <span><?php echo e($message); ?></span>
            <button class="absolute right-5 text-white font-bold" onclick="<?php echo e($closeFunction); ?>()">X</button>
        </div>

        <script>
            function <?php echo e($closeFunction); ?>() {
                document.getElementById('<?php echo e($id); ?>').classList.add('hidden');
            }

            setTimeout(function() {
                var el = document.getElementById('<?php echo e($id); ?>');
                if (el) el.classList.add('hidden');
            }, 5000);
        </script>
    <?php endif; ?>

    <h1 class="text-3xl font-semibold text-gray-800 mb-6">Manajemen Artikel</h1>

    <div class="mb-6">
        <a href="<?php echo e(route('admin.create')); ?>" class="bg-blue-600 text-white py-2 px-6 rounded-full shadow hover:bg-blue-700 transition duration-200">
            Tambah Artikel
        </a>
    </div>

    <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="bg-white p-6 rounded-lg shadow-lg transform hover:scale-105 transition duration-200">
            <?php if($article->image): ?>
                <img src="<?php echo e(asset('storage/' . $article->image)); ?>" alt="<?php echo e($article->title); ?>" class="w-full h-48 object-cover rounded mb-4">
            <?php endif; ?>
            <div class="flex justify-between items-center mt-4">
                <h2 class="text-xl font-semibold text-gray-900"><?php echo e($article->title); ?></h2>
                <div class="flex space-x-4">
                    <a href="<?php echo e(route('admin.edit', $article)); ?>" class="text-blue-600 hover:underline">Edit</a>
                    <p>|</p>
                    <form action="<?php echo e(route('admin.destroy', $article)); ?>" method="POST" class="inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="text-red-600 hover:underline">Hapus</button>
                    </form>
                </div>
            </div>
            <p class="text-gray-700 mt-2"><?php echo e(Str::limit($article->content, 150)); ?></p>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Acer NITRO 5\Documents\Mengoding\Modul4\PAW_MODUL4\resources\views/admin/index.blade.php ENDPATH**/ ?>